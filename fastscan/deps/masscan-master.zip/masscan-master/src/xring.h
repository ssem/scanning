#ifndef XRING_H
#define XRING_H


int xring_selftest(void);

#endif
