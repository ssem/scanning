#ifndef MASSCAN_VERSION

#define MASSCAN_VERSION "1.0.3"

#endif

