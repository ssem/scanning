#ifndef MAIN_READRANGE_H
#define MAIN_READRANGE_H
struct Masscan;

void
main_readrange(struct Masscan *masscan);

#endif
